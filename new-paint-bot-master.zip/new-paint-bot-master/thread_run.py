import math

import _thread
import time

import serial