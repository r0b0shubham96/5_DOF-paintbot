import math
import _thread
import time
import RPi.GPIO as GPIO 
from time import sleep

l1_dir_up = GPIO.HIGH
l1_dir_down = GPIO.LOW

wrist_dir_up = 0
wrist_dir_down = 1
wrist_dir_left = 2
wrist_dir_right = 3

base_dir_left = GPIO.LOW
base_dir_right = GPIO.HIGH

l2_dir_up = GPIO.LOW
l2_dir_down = GPIO.HIGH

driver_setup_pulses = 1600

base_gear = 110/15

## pin numbers [Pulse, Direction,  Enable]
wrist1_pins = [17, 27, 22]    # Rpi pins 11, 13, 15
wrist2_pins = [10, 9, 11]    # Rpi pins 19, 21, 23
link2_pins = [5, 6, 12]    # Rpi pins 29, 31, 32
base_pins = [13, 19, 26]    # Rpi pins 33, 35, 37
link1_pins = [23, 24]    # Rpi pins 16, 18

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(wrist1_pins[0], GPIO.OUT)
GPIO.setup(wrist1_pins[1], GPIO.OUT)
GPIO.setup(wrist1_pins[2], GPIO.OUT)

GPIO.setup(wrist2_pins[0], GPIO.OUT)
GPIO.setup(wrist2_pins[1], GPIO.OUT)
GPIO.setup(wrist2_pins[2], GPIO.OUT)

GPIO.setup(link2_pins[0], GPIO.OUT)
GPIO.setup(link2_pins[1], GPIO.OUT)
GPIO.setup(link2_pins[2], GPIO.OUT)

GPIO.setup(base_pins[0], GPIO.OUT)
GPIO.setup(base_pins[1], GPIO.OUT)
GPIO.setup(base_pins[2], GPIO.OUT)

GPIO.setup(link1_pins[0], GPIO.OUT)
GPIO.setup(link1_pins[1], GPIO.OUT)

link1_pin0 = GPIO.PWM(link1_pins[0], 100)
link1_pin0.start(0)

def angle_calculate(gear_ratio, angle):
    input_angle = angle * gear_ratio
    return ((input_angle/360) * driver_setup_pulses)

def time_pulse_calculate(time, total_pulses):
    return (time/total_pulses)

def wrist_direction(direction):
    if (direction == wrist_dir_up):
        GPIO.output(wrist1_pins[1], GPIO.LOW)
        GPIO.output(wrist2_pins[1], GPIO.HIGH)
    elif(direction == wrist_dir_down):
        GPIO.output(wrist1_pins[1], GPIO.HIGH)
        GPIO.output(wrist2_pins[1], GPIO.LOW)
    elif(direction == wrist_dir_left):
        GPIO.output(wrist1_pins[1], GPIO.HIGH)
        GPIO.output(wrist2_pins[1], GPIO.HIGH)
    elif(direction == wrist_dir_right):
        GPIO.output(wrist1_pins[1], GPIO.LOW)
        GPIO.output(wrist2_pins[1], GPIO.LOW)

def wrist_run(angle, time, direction):
    total_pulses = angle_calculate(1, angle)
    time_pulses = time_pulse_calculate(time, total_pulses)
    wrist_direction(direction)

    i = 0
    while (i < total_pulses):
        GPIO.output(wrist1_pins[0], GPIO.HIGH)
        GPIO.output(wrist2_pins[0], GPIO.HIGH)
        sleep(time_pulses/2)
        GPIO.output(wrist1_pins[0], GPIO.LOW)
        GPIO.output(wrist2_pins[0], GPIO.LOW)
        sleep(time_pulses/2)
        i += 1

def link2_run(angle, time, direction):
    total_pulses = angle_calculate(3, angle)
    time_pulses = time_pulse_calculate(time, total_pulses)
    GPIO.output(link2_pins[1], direction)
    
    i = 0

    while (i < total_pulses):
        GPIO.output(link2_pins[0], GPIO.HIGH)
        sleep(time_pulses/2)
        GPIO.output(link2_pins[0], GPIO.LOW)
        sleep(time_pulses/2)
        i += 1
        
def base_run(angle, time, direction):
    total_pulses = angle_calculate(base_gear, angle)
    time_pulses = time_pulse_calculate(time, total_pulses)
    GPIO.output(base_pins[1], direction)
    
    i = 0

    while (i < total_pulses):
        GPIO.output(base_pins[0], GPIO.HIGH)
        sleep(time_pulses/2)
        GPIO.output(base_pins[0], GPIO.LOW)
        sleep(time_pulses/2)
        i += 1

def link1_run(speed, time, direction):
    GPIO.output(link1_pins[1], direction)
    link1_pin0.ChangeDutyCycle(speed)
    sleep(time)
    link1_pin0.ChangeDutyCycle(0)
    
while True:
    link1_run(50, 2, l1_dir_up)
    base_run(90, 3, base_dir_right)
    wrist_run(30, 1, wrist_dir_down)
    wrist_run(10, 0.7, wrist_dir_right)
    link1_run(50, 1, l1_dir_down)
    base_run(60, 2, base_dir_left)
    wrist_run(30, 1, wrist_dir_up)
    wrist_run(10, 0.7, wrist_dir_left)
    base_run(30, 1, base_dir_left)
    link1_run(50, 1, l1_dir_down)
    
    link1_run(50, 2, l1_dir_up)
    base_run(90, 3, base_dir_left)
    wrist_run(30, 1, wrist_dir_down)
    wrist_run(10, 0.7, wrist_dir_right)
    link1_run(50, 1, l1_dir_down)
    base_run(60, 2, base_dir_right)
    wrist_run(30, 1, wrist_dir_up)
    wrist_run(10, 0.7, wrist_dir_left)
    base_run(30, 1, base_dir_right)
    link1_run(50, 1, l1_dir_down)




